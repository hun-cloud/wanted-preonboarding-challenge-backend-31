package com.ecommerce.wanted_cqrs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WantedCqrsApplication {

	public static void main(String[] args) {
		SpringApplication.run(WantedCqrsApplication.class, args);
	}

}
